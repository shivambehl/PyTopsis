# PyTopsis


PyTopsis is a Python Package implementing Topsis meathod used for multi-criteria decision analysis method
  - Easy to use
  - Numpy based
  - Ideal for Students

And offcourse, PyTopsis code is Open Source.

### Development

Want to contribute? Great!
Use your Python skills and creativity for easy decision making for the world.

License
----

MIT


**Free Software, Hell Yeah!**
